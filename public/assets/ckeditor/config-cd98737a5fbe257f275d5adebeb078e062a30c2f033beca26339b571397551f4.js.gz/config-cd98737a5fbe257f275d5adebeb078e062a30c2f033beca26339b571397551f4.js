CKEDITOR.editorConfig = function( config )
{
config.width=700;
config.height=100;
}
;
